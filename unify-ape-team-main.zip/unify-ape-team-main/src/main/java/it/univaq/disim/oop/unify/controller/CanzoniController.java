package it.univaq.disim.oop.unify.controller;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import it.univaq.disim.oop.unify.business.BusinessException;
import it.univaq.disim.oop.unify.business.CanzoneService;
import it.univaq.disim.oop.unify.business.UnifyBusinessFactory;
import it.univaq.disim.oop.unify.domain.Account;
import it.univaq.disim.oop.unify.domain.Artista;
import it.univaq.disim.oop.unify.domain.Canzone;
import it.univaq.disim.oop.unify.view.ViewDispatcher;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class CanzoniController implements Initializable, DataInitializable<Account>{

	@FXML
	private Button aggiungiButton;
	
    @FXML
    private Label canzoniLabel;
    
    @FXML
    private TableView<Canzone> tabellaCanzoni;
    
    @FXML
    private TableColumn<Canzone, String> titoloTableColumn;

    @FXML
    private TableColumn<Canzone, Artista> nomeArtistaTableColumn;

    @FXML
    private TableColumn<Canzone, String> testoTableColumn;
    
    @FXML
    private TableColumn<Canzone, Button> azioniTableColumn;

    private ViewDispatcher dispatcher;
    private CanzoneService canzoneService;
    
    private Account account;
    
    public CanzoniController() {
    	dispatcher = ViewDispatcher.getInstance();
    	UnifyBusinessFactory factory = UnifyBusinessFactory.getIstance();
    	canzoneService = factory.getCanzoneService();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
	    titoloTableColumn.setCellValueFactory(new PropertyValueFactory<>("titolo"));
	    nomeArtistaTableColumn.setCellValueFactory(new PropertyValueFactory<>("nomeArtista"));
	    testoTableColumn.setCellValueFactory(new PropertyValueFactory<>("testo"));
	    azioniTableColumn.setStyle("-fx-alignment: CENTER;");
	    azioniTableColumn.setCellValueFactory((CellDataFeatures<Canzone, Button> param) -> {
		    final Button canzoniButton = new Button("Modifica");
		    canzoniButton.setOnAction((ActionEvent event) -> {
		    	dispatcher.renderView("canzone", param.getValue());
		    });
		    return new SimpleObjectProperty<Button>(canzoniButton);
	    });
    }
      
    @Override
    public void dataInitializable(Account account) {
	   this.account = account;
	   try {
		   List<Canzone> canzoni = canzoneService.findAllCanzoni();
		   ObservableList<Canzone> canzoniDati = FXCollections.observableArrayList(canzoni);
		   tabellaCanzoni.setItems(canzoniDati);
	   } catch(BusinessException e) {
		   dispatcher.renderError(e);
	   }
    }

    @FXML
    void aggiungiCanzone(ActionEvent event) {
    	Canzone canzone = new Canzone();
    	dispatcher.renderView("canzone", canzone);
    }

}
