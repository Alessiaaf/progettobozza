package it.univaq.disim.oop.unify.controller;

import it.univaq.disim.oop.unify.domain.Account;

public interface DataInitializable<T> {

	default void dataInitializable(T t) {
			
	}

}
