package it.univaq.disim.oop.unify.controller;

import java.net.URL;
import java.time.LocalTime;
import java.util.ResourceBundle;

import it.univaq.disim.oop.unify.business.ArtistaService;
import it.univaq.disim.oop.unify.business.BusinessException;
import it.univaq.disim.oop.unify.business.UnifyBusinessFactory;
import it.univaq.disim.oop.unify.domain.Artista;
import it.univaq.disim.oop.unify.view.ViewDispatcher;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;

public class ArtistaController implements Initializable, DataInitializable<Artista>{

		private ViewDispatcher dispatcher;
		
		private Artista artista;
		
		private ArtistaService artistaService;
		
		private UnifyBusinessFactory factory;
	
	    @FXML
	    private Button annullaBottone;

	    @FXML
	    private TextArea biografia;

	    @FXML
	    private Button confermaBottone;

	    @FXML
	    private Label discografia;

	    @FXML
	    private Label erroreLabel;

	    @FXML
	    private ImageView foto;

	    @FXML
	    private Label id;

	    @FXML
	    private Label nome;     
    
	

    public ArtistaController() {
    	factory = UnifyBusinessFactory.getIstance();
    	dispatcher = ViewDispatcher.getInstance();
    	artistaService = factory.getArtistaService();

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {}
    
    @Override
    public void dataInitializable(Artista artista) {
    	this.artista = artista;
    	id.setText(Integer.toString(artista.getId()));
    	nome.setText(artista.getNome().toString());
    	biografia.setText(artista.getBiografia().toString());
    	discografia.setText(artista.getDiscografia().toString());
    	// foto.setImage(artista.getFoto()); da gestire come far visualizzare le foto ( sennò è pronta),
    										i//forse da cambiare la var foto in artista
    	
    }
 
    
    
    
    public void back(ActionEvent event) {
    	dispatcher.renderView("artisti", artista.getArtista());
    }
    
 
    //da cambiare   
    public void confirm(ActionEvent event) {
    	if(pagamento.isSelected()) {
    		try {
				artistaService.updateArtista(artista);
			} catch (BusinessException e) {
				e.printStackTrace();
			}
    		dispatcher.renderView("aggiungiChilometraggio", artista);
    	}
    	else {
    		if(ora.getValue().toString().isBlank() || minuto.getValue().toString().isBlank() || descrizione.getText().isBlank())
    			erroreLabel.setText("Inserisci tutti i parametri");
    		else {
    			artista.setStatoNoleggio(Stato_Noleggio.IN_CORSO);
    			artista.setOrarioRitiro(LocalTime.parse(ora.getValue().toString() + ":" + minuto.getValue().toString()));
    			try {
    				artistaService.updateArtista(artista);
    				dispatcher.renderView("artisti", artista.getArtista());
    			} catch (BusinessException e) {
    				dispatcher.renderError(e);
    			}
    		}
    	}				
    }
  
    
}