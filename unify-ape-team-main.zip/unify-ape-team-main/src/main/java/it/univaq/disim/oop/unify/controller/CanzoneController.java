package it.univaq.disim.oop.unify.controller;

import java.net.URL;
import java.util.ResourceBundle;

import it.univaq.disim.oop.unify.business.BusinessException;
import it.univaq.disim.oop.unify.business.CanzoneService;
import it.univaq.disim.oop.unify.business.UnifyBusinessFactory;
import it.univaq.disim.oop.unify.domain.Account;
import it.univaq.disim.oop.unify.domain.Artista;
import it.univaq.disim.oop.unify.domain.Canzone;
import it.univaq.disim.oop.unify.view.ViewDispatcher;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class CanzoneController implements Initializable,DataInitializable<Canzone>{
	
	 private ViewDispatcher dispatcher;
	 
	    private CanzoneService canzoneService;
	    
	    private Canzone canzone;
	    
	    private Artista artista;
	    
	    private UnifyBusinessFactory factory;
	    
	    private Account account;
	
	@FXML
	private TextField titolo;
	
    @FXML
    private ComboBox<Artista> nomeArtista;

    @FXML
    private TextArea testo;

    @FXML
    private Button salvaButton;
	
    @FXML
    private Button annullaButton;
    
    public CanzoneController() {
    	factory = UnifyBusinessFactory.getIstance();
	    dispatcher = ViewDispatcher.getInstance();
    	canzoneService = factory.getCanzoneService();
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    	//canzone.getItem().addAll(canzone.values());
    }

    @FXML
    public void salva(ActionEvent event) {
    	/*
	    try {
		    canzone.setTitolo(titolo.getText());
		    canzone.setNome(artista);
		    canzone.setTesto(testo.getText());
		    if (canzone.getId() == null) {
		    	canzoneService.addCanzone(canzone);
		    } else {
		    	canzoneService.updateCanzone(canzone);
		    }
		    dispatcher.renderView("canzoni", canzone.getCanzone());
		} catch (BusinessException e) {
		    dispatcher.renderError(e);
	      }
	    */
    }
  
    
    @FXML
    void annulla(ActionEvent event) {
    	dispatcher.renderView("canzoni", account);
    }

    @FXML
    void update(ActionEvent event) {
    	canzone.setTitolo(titolo.getText());
	    canzone.setNome(artista);
	    canzone.setTesto(testo.getText());
    }

}