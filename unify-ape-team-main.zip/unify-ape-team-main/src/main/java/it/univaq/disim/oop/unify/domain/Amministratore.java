package it.univaq.disim.oop.unify.domain;

public class Amministratore extends Account {

}
