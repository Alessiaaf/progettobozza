package it.univaq.disim.oop.unify.domain;

public class Utente extends Account {

}
