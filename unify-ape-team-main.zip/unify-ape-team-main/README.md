# Scheletro progetto Java

<div align="center">
  <b>Progetto dell’insegnamento di Laboratorio di Programmazione ad Oggetti</b>
  <br>
  <b>A.A. 2021/2022</b>
  <br>
  <b>Corso di Laurea in Informatica</b>
  <br>
  <b>Università degli studi dell'Aquila</b>
  <br>
  <b>Docente: Dott. Phuong T. Nguyen</b>
  <br>
  <b>Collaboratore: Dott. Amleto Di Salle</b>
  <br>
  <b>Collaboratore: Dott. Claudio Di Sipio</b>
  <br>
  <b>Collaboratore: Dott. Riccardo Rubei</b>

</div>


